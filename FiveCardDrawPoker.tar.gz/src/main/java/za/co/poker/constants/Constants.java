package za.co.poker.constants;

public class Constants {

	public static final int HAND_SIZE = 5;
	public static final int DECK_SIZE = 52;
	
}
