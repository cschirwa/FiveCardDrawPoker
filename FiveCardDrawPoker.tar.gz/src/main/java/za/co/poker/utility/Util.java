package za.co.poker.utility;

public class Util {

	public static void print(String msg, Object... args) {
		System.out.printf(msg + "\n", args);
	}
}
